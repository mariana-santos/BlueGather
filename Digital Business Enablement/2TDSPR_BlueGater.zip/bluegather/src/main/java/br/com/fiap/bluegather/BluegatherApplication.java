package br.com.fiap.bluegather;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BluegatherApplication {

	public static void main(String[] args) {
		SpringApplication.run(BluegatherApplication.class, args);
	}

}
