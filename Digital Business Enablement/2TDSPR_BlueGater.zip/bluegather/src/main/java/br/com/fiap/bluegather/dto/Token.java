package br.com.fiap.bluegather.dto;

public record Token(String token, String type, String prefix) {}