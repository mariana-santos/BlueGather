package br.com.fiap.bluegather;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BluegatherApplicationTests {

	@Test
	void contextLoads() {
	}

}
