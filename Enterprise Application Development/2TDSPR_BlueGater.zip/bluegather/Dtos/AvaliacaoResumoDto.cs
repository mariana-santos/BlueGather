﻿namespace bluegather.Dtos
{
    public class AvaliacaoResumoDto
    {
        public long IdEvento { get; set; }
        public long QtdAvaliadores { get; set; }
        public double MediaNota { get; set; }
    }
}